﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace WebAPI2020.Models
{
    public class DBModels : DbContext
    {
        public DBModels(): base("name=ConnectionString")
        {
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<EmployeeDetail> EmployeeDetails { get; set; }
    }
}