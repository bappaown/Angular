﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace WebAPI2020.Models
{
    public class Employee
    {
        [Key]
        public int ID { get; set; }
        [StringLength(100)]
        public string Name { get; set; }
        [StringLength(100)]
        public string EmailID { get; set; }
        public Int64 Mobile { get; set; }
        [StringLength(100)]
        public string Password { get; set; }
    }
}