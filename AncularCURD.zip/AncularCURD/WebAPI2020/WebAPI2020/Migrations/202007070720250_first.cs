namespace WebAPI2020.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class first : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.EmployeeDetails",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        EmployeeID = c.Int(nullable: false),
                        Position = c.String(maxLength: 100),
                        Gender = c.String(maxLength: 50),
                        Address = c.String(),
                        Photo = c.Binary(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Employees", t => t.EmployeeID, cascadeDelete: true)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(maxLength: 100),
                        EmailID = c.String(maxLength: 100),
                        Mobile = c.Long(nullable: false),
                        Password = c.String(maxLength: 100),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.EmployeeDetails", "EmployeeID", "dbo.Employees");
            DropIndex("dbo.EmployeeDetails", new[] { "EmployeeID" });
            DropTable("dbo.Employees");
            DropTable("dbo.EmployeeDetails");
        }
    }
}
