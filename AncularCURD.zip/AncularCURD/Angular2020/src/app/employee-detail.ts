import { Binary } from '@angular/compiler';

export class EmployeeDetail {
    ID: number;
    EmployeeID: number;
    Position: string;
    Gender: string;
    Address: string;
    Photo: string;
}
