import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';
import { Observable } from 'rxjs';
import { FileUploader } from 'ng2-file-upload';
import { Employee } from '../employee';
import { EmployeeDetail } from '../employee-detail'; 
import { EmployeeViewModel } from '../employee-view-model'; 

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {  
  dataSaved = false;
  message = null;
  employeeForm: FormGroup;
  allEmployees: Observable<EmployeeViewModel[]>; 
  options: string;
  selectedPosition: any = [];
  url: any;
  photo: File;

  //public uploader: FileUploader = new FileUploader({ url: '../../assets/images', method: 'POST' });

  constructor(private formBuilder: FormBuilder, private data: DataService) { }

  ngOnInit(): void {
    this.employeeForm=this.formBuilder.group({
      ID:['',null],
      Name:['',[Validators.required]],
      EmailID:['',[Validators.required]],
      Mobile:['',[Validators.required]],
      Gender:[''],
      Position:[''],
      Address:[''],
      Photo:['']
     });
    this.loadAllEmployees();
  }

  loadAllEmployees(){
    this.allEmployees = this.data.getAllEmployee();
    
  }

  onFormSubmit(){
    if (this.employeeForm.valid) {
    this.dataSaved=false;
    let employee=this.employeeForm.value;
    employee.Position=this.selectedPosition.toString();

        this.data.UpdateEmployee(employee).subscribe(()=>{
         this.dataSaved=true;
         this.message="Record Updated Successfully.";
         this.loadAllEmployees();
         this.employeeForm.reset();
         this.selectedPosition='';
       });
      }
      else{
        this.dataSaved=true;
        this.message="Please check the required field.";
      }
  }

  loadEmployeeToEdit(Id: number){
    this.data.getEmployeeById(Id).subscribe(employee=>{
      this.dataSaved=false;
      this.message=null;
     
      this.employeeForm.controls['ID'].setValue(employee[0].Employee.ID);
      this.employeeForm.controls['Name'].setValue(employee[0].Employee.Name);
      this.employeeForm.controls['EmailID'].setValue(employee[0].Employee.EmailID);
      this.employeeForm.controls['Mobile'].setValue(employee[0].Employee.Mobile);
      
      if(employee[0].EmployeeDetail != null){
        this.employeeForm.controls['Gender'].setValue(employee[0].EmployeeDetail.Gender);
        this.employeeForm.controls['Address'].setValue(employee[0].EmployeeDetail.Address);
        this.employeeForm.controls['Photo'].setValue(employee[0].EmployeeDetail.Photo);
        this.url=employee[0].EmployeeDetail.Photo;
        this.selectedPosition=employee[0].EmployeeDetail.Position.split(",");
      }
      else{
        this.employeeForm.controls['Gender'].setValue('');
        this.employeeForm.controls['Address'].setValue('');
        this.employeeForm.controls['Photo'].setValue('');
        this.url='';
        this.selectedPosition='';
      }
    });
  }

  deleteEmployee(Id: number){
    if(confirm('Are you sure want to delete?')){
      this.data.DeleteEmployeeById(Id).subscribe(()=>{
        this.dataSaved=true;
        this.message="Record Deleted Successfully.";
        this.loadAllEmployees();
        this.employeeForm.reset();
      });
    }
  }

  resetForm(){
    this.employeeForm.reset();
    this.dataSaved=false;
    this.message=null;
    this.selectedPosition='';
    this.url=null;
  }

  checkPosition(event){
    if(event.target.checked){
      //To add checked value
      this.selectedPosition.push(event.target.value);
    }
    else{
      //To remove unchecked value
      this.selectedPosition=this.selectedPosition.filter(x => x != event.target.value);
    }
    //To remove empty value
    this.selectedPosition = this.selectedPosition.filter(item => item);
  }

  uploadPhoto(event){
    if(event.target.files){
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (event) => { 
        this.url = event.target.result; 
        this.employeeForm.controls['Photo'].setValue(event.target.result);
      };
    }
  }

}
