import { EmployeeDetail } from './employee-detail';

describe('EmployeeDetail', () => {
  it('should create an instance', () => {
    expect(new EmployeeDetail()).toBeTruthy();
  });
});
