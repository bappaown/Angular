import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs'; 
import { Employee } from './employee'; 
import { EmployeeDetail } from './employee-detail'; 
import { EmployeeViewModel } from './employee-view-model'; 

@Injectable({
  providedIn: 'root'
})
export class DataService {

  url='http://localhost:7070/api/Employee';

  constructor(private http: HttpClient) { }

  getAllEmployee(): Observable<EmployeeViewModel[]> {
    return this.http.get<EmployeeViewModel[]>(this.url + '/GetEmployees');
  }

  getEmployeeById(Id: number): Observable<EmployeeViewModel>{
    return this.http.get<EmployeeViewModel>(this.url + '/GetEmployee/'+ Id);
  }

  getLogin(EmailID: string, Password: string): Observable<Employee>{
    return this.http.get<Employee>(this.url + '/GetLogin/?EmailID='+ EmailID +'&Password='+ Password);
  }

  createEmployee(employee: Employee): Observable<number>{
    let httpHeaders=new HttpHeaders().set('Content-Type', 'application/json');
    let options={headers: httpHeaders};
    return this.http.post<number>(this.url +'/PostEmployee', employee, options);
  }

  UpdateEmployee(employee: any): Observable<number>{
    let httpHeaders=new HttpHeaders().set('Content-Type', 'application/json');
    let options={headers: httpHeaders};
  
    return this.http.put<number>(this.url +'/PutEmployee', employee, options);
  }

  DeleteEmployeeById(Id: number): Observable<number>{
    let httpHeaders=new HttpHeaders().set('Content-Type', 'application/json');

    return this.http.delete<number>(this.url +'/DeleteEmployee/'+ Id);
  }

}
