import { EmployeeViewModel } from './employee-view-model';

describe('EmployeeViewModel', () => {
  it('should create an instance', () => {
    expect(new EmployeeViewModel()).toBeTruthy();
  });
});
