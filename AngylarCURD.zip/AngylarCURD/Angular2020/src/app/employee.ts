export class Employee {
    ID: number;
    Name: string;
    EmailID: string;
    Mobile: number;
    Password: string;
}
