import { Employee } from './employee'; 
import { EmployeeDetail } from './employee-detail';

export class EmployeeViewModel {
    Employees: Employee
    EmployeeDetails: EmployeeDetail

}
