import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  dataSaved=false;
  message=null;
  employeeForm: FormGroup;
  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private data: DataService) { }

  ngOnInit(): void {
    this.employeeForm=this.formBuilder.group({
      Name:['',[Validators.required]],
      EmailID:['',[Validators.required]],
      Mobile:['',[Validators.required]],
      Password:['',[Validators.required]],
      ConfirmPassword:['',[Validators.required]]
     });

     this.loginForm=this.formBuilder.group({
      EmailID:['',[Validators.required]],
      Password:['',[Validators.required]]
     });
  }

  onFormSubmit(){
    if (this.employeeForm.valid) {
    this.dataSaved=false;
    let employee=this.employeeForm.value;

    if(employee.Password == employee.ConfirmPassword){
    delete employee.ConfirmPassword;

    this.data.createEmployee(employee).subscribe(()=>{
       this.dataSaved=true;
       this.message="Record Saved Successfully.";
       this.employeeForm.reset();
       });
    }
    else{
      this.dataSaved=true;
      this.message="Password Mismatch.";
    }
  }
  else
  {
    this.dataSaved=true;
    this.message="Please check the required field.";
  }
  }

  resetForm(){
    this.employeeForm.reset();
    this.dataSaved=false;
    this.message=null;
  }

  onLogin(){
    if (this.loginForm.valid) {
    this.dataSaved=false;
    let emp=this.loginForm.value;
    this.data.getLogin(emp.EmailID,emp.Password).subscribe(()=>{
      this.dataSaved=true;
      this.message="Login Successfully.";
      this.loginForm.reset();
    });
  }
  else
  {
    this.dataSaved=true;
    this.message="Please check the required field.";
  }
  }

}
