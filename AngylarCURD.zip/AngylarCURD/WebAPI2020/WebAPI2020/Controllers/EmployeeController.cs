﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI2020.Models;

namespace WebAPI2020.Controllers
{
    public class EmployeeController : ApiController
    {

        DBModels db = new DBModels();

        [HttpGet]
        public IHttpActionResult GetEmployees()
        {
            try
            {
                var Emp = (from p in db.Employees
                           join o in db.EmployeeDetails on p.ID equals o.EmployeeID into po
                           from o in po.DefaultIfEmpty()
                           select new EmployeeViewModel { Employee = p, EmployeeDetail = o });

                return Content(HttpStatusCode.OK, Emp);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        public IHttpActionResult GetEmployee(int ID)
        {
            try
            {
                var Emp = (from p in db.Employees
                           join o in db.EmployeeDetails on p.ID equals o.EmployeeID into po
                           from o in po.DefaultIfEmpty()
                           where p.ID == ID
                           select new EmployeeViewModel { Employee = p, EmployeeDetail = o });

                return Content(HttpStatusCode.OK, Emp);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        public IHttpActionResult GetAllEmployee()
        {
            List<Employee> employees = new List<Employee>();
            try
            {
                employees = db.Employees.ToList();

                return Content(HttpStatusCode.OK, employees);
            }
            catch (Exception)
            {
                throw;
            }
        }
        // GET api/Employee/2
        [HttpGet]
        public IHttpActionResult GetEmployeeById(int id)
        {
            try
            {
                Employee employee = db.Employees.Find(id);
                if (employee == null)
                {
                    // return NotFound();
                    return Content(HttpStatusCode.NotFound, employee);
                }
                return Content(HttpStatusCode.OK, employee);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpGet]
        public IHttpActionResult GetLogin(string EmailID, string Password)
        {
            try
            {
                Employee employee = db.Employees.Where(b => b.EmailID == EmailID && b.Password == Password).FirstOrDefault();
                if (employee == null)
                {
                    return Content(HttpStatusCode.NotFound, employee);
                }
                return Content(HttpStatusCode.OK, employee);
            }
            catch (Exception)
            {
                throw;
            }
        }

        // POST api/Employee
        [HttpPost]
        public IHttpActionResult PostEmployee(Employee employee)
        {
            string Errors = "";
            int result = 0;

            try
            {
                if (ModelState.IsValid)
                {
                    db.Employees.Add(employee);
                    result = db.SaveChanges();
                }
                else
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors);
                    string _Errors = "";
                    foreach (var a in errors)
                    {
                        if (a.ErrorMessage.Trim() != "")
                        {
                            if (_Errors.Trim() != "")
                            {
                                Errors = Errors + ",  ";
                            }
                            Errors = Errors + "*" + a.ErrorMessage;
                        }
                        else
                        {
                            Errors = Errors + a.Exception.InnerException.Message;
                        }
                    }
                }
                if (result > 0)
                {
                    return Content(HttpStatusCode.OK, result);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, result);
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        // PUT api/Employee/5
        [HttpPut]
        public IHttpActionResult PutEmployee(object employee)
        {
            int rec = 0;
            var data = (JObject)employee;
            int ID = Convert.ToInt32(data["ID"]);
            string Name = Convert.ToString(data["Name"]);
            string EmailID = Convert.ToString(data["EmailID"]);
            Int64 Mobile = Convert.ToInt64(data["Mobile"]);
            string Address = Convert.ToString(data["Address"]);
            string Position = Convert.ToString(data["Position"]);
            string Gender = Convert.ToString(data["Gender"]);
            string Photo = Convert.ToString(data["Photo"]);

            try
            {
                Employee emp = db.Employees.Find(ID);
                if (emp == null)
                {
                    return NotFound();
                }
                emp.Name = Name;
                emp.EmailID = EmailID;
                emp.Mobile = Mobile;

                EmployeeDetail empdetail = db.EmployeeDetails.Where(b => b.EmployeeID == ID).FirstOrDefault();
                if (empdetail == null)
                {
                    empdetail = new EmployeeDetail();
                    empdetail.EmployeeID = ID;
                    empdetail.Position = Position;
                    empdetail.Gender = Gender;
                    empdetail.Address = Address;
                    empdetail.Photo = Photo;
                    db.EmployeeDetails.Add(empdetail);
                }
                else
                {
                    empdetail.EmployeeID = ID;
                    empdetail.Position = Position;
                    empdetail.Gender = Gender;
                    empdetail.Address = Address;
                    if (Photo != string.Empty)
                        empdetail.Photo = Photo;
                }
                rec = db.SaveChanges();

                if (rec > 0)
                {
                    return Content(HttpStatusCode.OK, true);
                }
                else
                {
                    return Content(HttpStatusCode.BadRequest, false);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // DELETE api/Employee/5
        [HttpDelete]
        public IHttpActionResult DeleteEmployee(int ID)
        {
            string Errors = "";
            int result = 0;

            try
            {
                Employee employee = db.Employees.Find(ID);
                EmployeeDetail empdetail = db.EmployeeDetails.Where(b => b.EmployeeID == ID).FirstOrDefault();
                if (ID > 0 && employee != null)
                {
                    db.Employees.Remove(employee);
                    if (empdetail != null)
                    {
                        db.EmployeeDetails.Remove(empdetail);
                    }
                    result = db.SaveChanges();
                }
                else
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors);
                    string _Errors = "";
                    foreach (var a in errors)
                    {
                        if (a.ErrorMessage.Trim() != "")
                        {
                            if (_Errors.Trim() != "")
                            {
                                Errors = Errors + ",  ";
                            }
                            Errors = Errors + "*" + a.ErrorMessage;
                        }
                        else
                        {
                            Errors = Errors + a.Exception.InnerException.Message;
                        }
                    }
                }
                if (result > 0)
                {
                    return Content(HttpStatusCode.OK, true);
                }
                else
                {
                    return Content(HttpStatusCode.NotFound, false);
                }

            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}
