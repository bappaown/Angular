namespace WebAPI2020.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class first1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.EmployeeDetails", "EmployeeID", "dbo.Employees");
            DropIndex("dbo.EmployeeDetails", new[] { "EmployeeID" });
        }
        
        public override void Down()
        {
            CreateIndex("dbo.EmployeeDetails", "EmployeeID");
            AddForeignKey("dbo.EmployeeDetails", "EmployeeID", "dbo.Employees", "ID", cascadeDelete: true);
        }
    }
}
