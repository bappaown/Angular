﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace WebAPI2020.Models
{
    public class EmployeeDetail
    {
        [Key]
        public Int32 ID { get; set; }
        public int EmployeeID { get; set; }
        [StringLength(100)]
        public string Position { get; set; }
        [StringLength(50)]
        public string Gender { get; set; }
        public string Address { get; set; }
        public string Photo { get; set; }
    }
}