﻿using AngularService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AngularService.Controllers
{
    public class EmployeeController : ApiController
    {
        AngularDBEntities db = new AngularDBEntities();

        public IQueryable<Employee> GetEmployees()
        {
            try
            {
                return db.Employees;
            }
            catch (Exception)
            {
                throw;
            }
        }

        // GET api/Employee/2
        [HttpGet]
        public IHttpActionResult GetEmployee(int id)
        {
            try
            {
                Employee employee = db.Employees.Find(id);
                if (employee == null)
                {
                    return NotFound();
                }
                return Ok(employee);
            }
            catch (Exception)
            {
                throw;
            }
        }

        // POST api/Employee
        [HttpPost]
        public IHttpActionResult PostEmployee(Employee employee)
        {
            try
            {
                //if (ModelState.IsValid)
                //{
                db.Employees.Add(employee);
                db.SaveChanges();
                //}
                //else
                //{
                //    return BadRequest(ModelState);
                //}
            }
            catch (Exception)
            {
                throw;
            }

            return Ok(employee);
        }

        // PUT api/Employee/5
        [HttpPut]
        public IHttpActionResult PutEmployee(int ID, Employee employee)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Employee emp = db.Employees.Find(ID);
                    if (emp == null)
                    {
                        return NotFound();
                    }
                    emp.FullName = employee.FullName;
                    emp.EmpCode = employee.EmpCode;
                    emp.Mobile = employee.Mobile;
                    emp.Position = employee.Position;
                    //db.Entry(employee).State = EntityState.Modified;
                    db.SaveChanges();
                }
                else
                {
                    return BadRequest(ModelState);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return Ok(employee);
        }

        // DELETE api/Employee/5
        [HttpDelete]
        public IHttpActionResult DeleteEmployee(int ID)
        {
            try
            {
                Employee employee = db.Employees.Find(ID);
                if (employee == null)
                {
                    return NotFound();
                }
                db.Employees.Remove(employee);
                db.SaveChanges();

                return Ok(employee);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
