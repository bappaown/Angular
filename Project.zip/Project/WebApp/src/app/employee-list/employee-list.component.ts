import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private service: EmployeeService) { }

  ngOnInit(): void {
    this.service.getEmployees();
  }

  poputaleForm(emp: Employee){
    // this.service.formData = emp;
    this.service.formData = Object.assign({}, emp);
  }

  onDelete(ID: number){
    this.service.deleteEmployee(ID).subscribe(res => {
      this.service.getEmployees();
    });
  }

}
