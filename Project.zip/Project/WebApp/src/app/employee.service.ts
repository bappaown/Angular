import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee'; 

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

formData: Employee;
empList: Employee[];
rootURL='http://localhost:9090/api/Employee';

  constructor(private http: HttpClient) { }

  getEmployees(){
    return this.http.get(this.rootURL +'/GetEmployees').subscribe(emp => this.empList = emp as Employee[]);
  }

  postEmployee(formData: Employee){
    return this.http.post(this.rootURL +'/PostEmployee', formData);
  }

  putEmployee(formData: Employee){
    return this.http.put(this.rootURL +'/PutEmployee/'+formData.EmployeeID, formData);
  }

  deleteEmployee(ID: number){
    return this.http.delete(this.rootURL +'/DeleteEmployee/'+ID);
  }
}
